import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IssueBookForm extends JFrame {

	static IssueBookForm frame;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new IssueBookForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IssueBookForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 387);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIssueBook = new JLabel("Issue Book");
		lblIssueBook.setBounds(159, 13, 88, 16);
		contentPane.add(lblIssueBook);
		
		JLabel BookIDLbl = new JLabel("Book ID:");
		BookIDLbl.setBounds(59, 88, 56, 16);
		contentPane.add(BookIDLbl);
		
		JLabel IDLbl = new JLabel("Issued To:");
		IDLbl.setBounds(59, 119, 82, 16);
		contentPane.add(IDLbl);
		
		JLabel lblNewLabel_2 = new JLabel("Issued By:");
		lblNewLabel_2.setBounds(59, 148, 97, 16);
		contentPane.add(lblNewLabel_2);
		
		JLabel ContactLbl = new JLabel("Issue Date:");
		ContactLbl.setBounds(59, 177, 82, 16);
		contentPane.add(ContactLbl);
		
		textField = new JTextField();
		textField.setBounds(224, 85, 116, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(224, 116, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setText("");
		textField_2.setBounds(224, 145, 116, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setText("");
		textField_3.setBounds(224, 174, 116, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton IssueBtn = new JButton("Issue Book");
		IssueBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String bookcallno=textField.getText();
				String issued_to=textField_1.getText();
				String issued_by=textField_2.getText();
				String issued_date=textField_3.getText();
				
				if(IssueBookDao.checkBook(bookcallno) && IssueBookDao.checkLibrarian(issued_by) && IssueBookDao.checkMembers(issued_to) && IssueBookDao.checkLimit(issued_to)){
				
				int i=IssueBookDao.save(bookcallno, issued_to, issued_by, issued_date);
				if(i>0){
					JOptionPane.showMessageDialog(IssueBookForm.this,"Book issued successfully!");
					LibrarianSuccess.main(new String[]{});
					frame.dispose();
					
					
				}else{
					JOptionPane.showMessageDialog(IssueBookForm.this,"Sorry, unable to issue!");
				}//end of save if-else
				
				}else{
					JOptionPane.showMessageDialog(IssueBookForm.this,"Sorry, Book_id doesn't exist!");
				}//end of checkbook if-else
				
			}
		});
		IssueBtn.setBounds(77, 263, 97, 25);
		contentPane.add(IssueBtn);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LibrarianSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		btnBack.setBounds(224, 263, 97, 25);
		contentPane.add(btnBack);
	}

}
