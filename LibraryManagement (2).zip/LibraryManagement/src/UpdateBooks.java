import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateBooks extends JFrame {

	static UpdateBooks frame;
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new UpdateBooks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateBooks() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblReturnBook = new JLabel("Add to Existing Books");
		lblReturnBook.setForeground(Color.GRAY);
		lblReturnBook.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblReturnBook.setBounds(154, 13, 124, 16);
		contentPane.add(lblReturnBook);
		
		JLabel BookIDLbl = new JLabel("Book ID");
		BookIDLbl.setBounds(69, 96, 56, 16);
		contentPane.add(BookIDLbl);
		
		JLabel StudIDLbl = new JLabel("Quantity");
		StudIDLbl.setBounds(69, 150, 82, 16);
		contentPane.add(StudIDLbl);
		
		textField = new JTextField();
		textField.setBounds(214, 93, 116, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(214, 147, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton AddBtn = new JButton("Add to Existing Books");
		AddBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String bookid=textField.getText();
				String quantity = textField_1.getText();
				int i=BookDao.update(bookid, quantity);
				if(i>0){
					JOptionPane.showMessageDialog(UpdateBooks.this,"Books added successfully!");
					LibrarianSuccess.main(new String[]{});
					frame.dispose();
					
				}else{
					JOptionPane.showMessageDialog(UpdateBooks.this,"Sorry, unable to add book!");
				}
			}
		});
		AddBtn.setBounds(98, 218, 220, 25);
		contentPane.add(AddBtn);
		
		JButton BAckBtn = new JButton("Back");
		BAckBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LibrarianSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		BAckBtn.setBounds(154, 256, 110, 25);
		contentPane.add(BAckBtn);
	}
}
