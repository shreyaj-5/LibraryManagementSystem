import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MembersDbs {
	
	public static int save(String name,String email,String address,String city,String contact, String memlevel){
		int status=0;
		try{
			Connection con=DB.connection();
			PreparedStatement ps=con.prepareStatement("insert into members(mem_name,email,address,city,Ph_no,mem_level) values(?,?,?,?,?,?)");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,address);
			ps.setString(4,city);
			ps.setString(5,contact);
			ps.setString(6,memlevel);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public static int update(String id, String name,String email,String address,String city,String contact, String memlevel){
		int status=0;
		try{
			Connection con=DB.connection();
			PreparedStatement ps=con.prepareStatement("update members set mem_name=?,email=?,address=?,city=?,Ph_no=?,mem_level=? where mem_id =?");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,address);
			ps.setString(4,city);
			ps.setString(5,contact);
			ps.setString(6,memlevel);
			ps.setString(7,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

}
