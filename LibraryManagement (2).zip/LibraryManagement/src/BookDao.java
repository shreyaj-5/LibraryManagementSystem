import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BookDao {
	public static int save(String name,String author,String publisher,String quantity){
		int status=0;
		try{
			Connection con=DB.connection();
			PreparedStatement ps=con.prepareStatement("insert into books(book_name,author,publisher,quantity) values(?,?,?,?)");
			ps.setString(1,name);
			ps.setString(2,author);
			ps.setString(3,publisher);
			ps.setString(4,quantity);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

	public static int update(String id, String quantity){
		int status=0;
		try{
			Connection con=DB.connection();
			PreparedStatement ps=con.prepareStatement("update books set quantity=? where book_id = ?");
			ps.setString(1,quantity);
			ps.setString(2,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}
