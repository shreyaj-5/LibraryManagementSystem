import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class UpdateMem extends JFrame {
	static int inputid;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	static UpdateMem frame ;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new UpdateMem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateMem() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(159, 113, 56, 16);
		contentPane.add(label);
		
		JLabel lblEnterLibrarianId = new JLabel("Enter Member ID");
		lblEnterLibrarianId.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblEnterLibrarianId.setBounds(28, 53, 151, 57);
		contentPane.add(lblEnterLibrarianId);
		
		JTextField textField = new JTextField();
		textField.setBounds(213, 64, 207, 37);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				inputid = Integer.parseInt(textField.getText());
				boolean status = false;
				try{
					Connection con=DB.connection();
					PreparedStatement ps=con.prepareStatement("select * from members where mem_id=?");
					ps.setString(1,Integer.toString(inputid));
					ResultSet rs=ps.executeQuery();
					status=rs.next();
					con.close();
				}catch(Exception e){System.out.println(e);}
				if(status == true) {
					UpdateMember.main(null);
					frame.dispose();
				}
				else {
					JOptionPane.showMessageDialog(UpdateMem.this, "Member not found!");
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(28, 142, 151, 32);
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(211, 142, 145, 32);
		contentPane.add(btnBack);
	}

}
