import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DB {
	static Connection conn;
	static ResultSet sr;

	public static Connection connection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "scott");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

}
