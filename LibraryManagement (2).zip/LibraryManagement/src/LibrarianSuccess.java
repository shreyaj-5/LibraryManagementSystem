import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LibrarianSuccess extends JFrame {
	static LibrarianSuccess frame;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new LibrarianSuccess();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LibrarianSuccess() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 412, 359);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLibrarianSection = new JLabel("Librarian Section");
		lblLibrarianSection.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblLibrarianSection.setBounds(135, 29, 154, 35);
		contentPane.add(lblLibrarianSection);
		
		JButton AddBooks = new JButton("Add Books");
		AddBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BooksForm.main(new String[]{});
				frame.dispose();
			}
		});
		AddBooks.setBounds(43, 115, 136, 25);
		contentPane.add(AddBooks);
		
		JButton View = new JButton("View Books");
		View.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewBooks.main(null);
				
			}
		});
		View.setBounds(222, 115, 136, 25);
		contentPane.add(View);
		
		JButton Issue = new JButton("Issue Book");
		Issue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IssueBookForm.main(new String[]{});
				frame.dispose();
			}
		});
		Issue.setBounds(43, 153, 136, 25);
		contentPane.add(Issue);
		
		JButton Return = new JButton("Update Books");
		Return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateBooks.main(new String[]{});
				frame.dispose();
			}
		});
		Return.setBounds(222, 153, 136, 25);
		contentPane.add(Return);
		
		JButton Logout = new JButton("Log out");
		Logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Library.main(new String[]{});
				frame.dispose();
			}
		});
		Logout.setBounds(135, 274, 136, 25);
		contentPane.add(Logout);
		
		JButton btnNewButton = new JButton("Add Members");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddMembers.main(null);
				frame.dispose();
			}
		});
		btnNewButton.setBounds(43, 191, 136, 25);
		contentPane.add(btnNewButton);
		
		
		JButton btnNewButton_2 = new JButton("Update Members");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UpdateMem.main(null);
				frame.dispose();
			}
		});
		btnNewButton_2.setBounds(222, 191, 136, 25);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("View Members");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewMembers.main(null);
				
			}
		});
		btnNewButton_3.setBounds(43, 229, 136, 25);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_1 = new JButton("View Issued");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewIssued.main(null);
			
			}
		});
		btnNewButton_1.setBounds(222, 229, 136, 25);
		contentPane.add(btnNewButton_1);
	}
}
