import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DeleteLibrarian extends JFrame {

	static DeleteLibrarian frame;
	
	private JPanel contentPane;
	private JTextField EmailField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new DeleteLibrarian();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteLibrarian() {
		setTitle("Open-hearted Library");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel LibIDLbl = new JLabel("Librarian ID: ");
		LibIDLbl.setBounds(67, 84, 97, 16);
		contentPane.add(LibIDLbl);

		EmailField = new JTextField();
		EmailField.setBounds(172, 81, 153, 22);
		contentPane.add(EmailField);
		EmailField.setColumns(10);

		JButton DeleteBtn = new JButton("Delete ");
		DeleteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String sid = EmailField.getText();
				if (sid == null || sid.trim().equals("")) {
					JOptionPane.showMessageDialog(DeleteLibrarian.this, "Id can't be blank");
				} else {
					int id = Integer.parseInt(sid);
					int i = LibrarianDbs.delete(id);
					if (i > 0) {
						JOptionPane.showMessageDialog(DeleteLibrarian.this, "Record deleted successfully!");
					} else {
						JOptionPane.showMessageDialog(DeleteLibrarian.this, "Unable to delete given id!");
					}
				}
			}
		});
		DeleteBtn.setBounds(108, 165, 97, 25);
		contentPane.add(DeleteBtn);

		JButton BackBtn = new JButton("Back");
		BackBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		BackBtn.setBounds(217, 165, 97, 25);
		contentPane.add(BackBtn);

		JLabel lblDeleteLibrarian = new JLabel("Delete Librarian");
		lblDeleteLibrarian.setForeground(Color.GRAY);
		lblDeleteLibrarian.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblDeleteLibrarian.setBounds(148, 24, 139, 22);
		contentPane.add(lblDeleteLibrarian);
	}
}
