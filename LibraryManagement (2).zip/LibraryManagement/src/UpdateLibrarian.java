import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class UpdateLibrarian extends JFrame {

	static int inputid;
	private JPanel contentPane;
	private JTextField textField;
	static UpdateLibrarian frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new UpdateLibrarian();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateLibrarian() {
		setTitle("Open Hearted Library");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 563, 266);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(159, 113, 56, 16);
		contentPane.add(label);
		
		JLabel lblEnterLibrarianId = new JLabel("Enter Librarian ID");
		lblEnterLibrarianId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblEnterLibrarianId.setBounds(28, 53, 246, 57);
		contentPane.add(lblEnterLibrarianId);
		
		textField = new JTextField();
		textField.setBounds(286, 66, 207, 37);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				inputid = Integer.parseInt(textField.getText());
				boolean status = false;
				try{
					Connection con=DB.connection();
					PreparedStatement ps=con.prepareStatement("select * from librarians where Lib_id=?");
					ps.setString(1,Integer.toString(inputid));
					ResultSet rs=ps.executeQuery();
					status=rs.next();
					con.close();
				}catch(Exception e){System.out.println(e);}
				if(status == true) {
					UpdateLib.main(null);
					frame.dispose();
				}
				else {
					JOptionPane.showMessageDialog(UpdateLibrarian.this, "Librarian not found!");
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(104, 123, 151, 37);
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(277, 123, 151, 37);
		contentPane.add(btnBack);
	}
}
