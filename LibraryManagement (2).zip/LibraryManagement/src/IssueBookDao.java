import java.sql.*;
public class IssueBookDao {
	
public static boolean checkBook(String bookcallno){
	boolean status=false;
	try{
		Connection con=DB.connection();
		PreparedStatement ps=con.prepareStatement("select * from books where book_id=?");
		ps.setString(1,bookcallno);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static boolean checkLibrarian(String lib_id){
	boolean status=false;
	try{
		Connection con=DB.connection();
		PreparedStatement ps=con.prepareStatement("select * from librarians where lib_id=?");
		ps.setString(1,lib_id);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static boolean checkMembers(String mem_id){
	boolean status=false;
	try{
		Connection con=DB.connection();
		PreparedStatement ps=con.prepareStatement("select * from members where mem_id=?");
		ps.setString(1,mem_id);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static boolean checkLimit(String mem_id){
	boolean status=false;
	try{
		Connection con=DB.connection();
		PreparedStatement ps=con.prepareStatement("select m.num_books, l.book_limit from members m JOIN mem_level l ON m.mem_level = l.mem_level "
				+ "where num_books<book_limit AND m.mem_id=?");
		ps.setString(1,mem_id);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int save(String book_id,String Issued_to,String issued_by,String issue_date){
	int status=0;
	int status1=0;
	try{
		Connection con=DB.connection();
		
		status=updatebook(book_id);//updating quantity and issue
		status1 = updateMem(Issued_to);
		if(status>0 && status1>0){
		PreparedStatement ps=con.prepareStatement("insert into issue (book_id, issued_to, issuer_id, issued_date) values(?,?,?,TO_date('"+issue_date+"','DD-MM-YYYY'))");
		ps.setString(1,book_id);
		ps.setString(2,Issued_to);
		ps.setString(3,issued_by);
		status=ps.executeUpdate();
		}
		
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updatebook(String bookcallno){
	int status=0;
	int quantity=0,issued=0;
	try{
		Connection con=DB.connection();
		
		PreparedStatement ps=con.prepareStatement("select quantity, issued_quantity from books where book_id=?");
		ps.setString(1,bookcallno);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			quantity=rs.getInt("quantity");
			issued=rs.getInt("issued_quantity");
		}
		
		if(quantity>0){
		PreparedStatement ps2=con.prepareStatement("update books set quantity=?,issued_quantity=? where book_id=?");
		ps2.setInt(1,quantity-1);
		ps2.setInt(2,issued+1);
		ps2.setString(3,bookcallno);
		
		status=ps2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updateMem(String mem_id){
	int status=0;
	int issued=0;
	try{
		Connection con=DB.connection();
		
		PreparedStatement ps=con.prepareStatement("select num_books from members where mem_id=?");
		ps.setString(1,mem_id);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			issued=rs.getInt("num_books");
		}
		
		
		PreparedStatement ps2=con.prepareStatement("update members set num_books=? where mem_id=?");
		ps2.setInt(1,issued+1);
		ps2.setString(2,mem_id);
		
		status=ps2.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}
