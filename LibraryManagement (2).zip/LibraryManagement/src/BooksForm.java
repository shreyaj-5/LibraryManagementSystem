import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BooksForm extends JFrame {
	static BooksForm frame;
	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new BooksForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BooksForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 359);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddBooks = new JLabel("Add books");
		lblAddBooks.setBounds(180, 13, 97, 16);
		contentPane.add(lblAddBooks);
		
		JLabel NameLbl = new JLabel("Name: ");
		NameLbl.setBounds(30, 78, 56, 16);
		contentPane.add(NameLbl);
		
		JLabel AuthLbl = new JLabel("Author: ");
		AuthLbl.setBounds(30, 109, 56, 16);
		contentPane.add(AuthLbl);
		
		JLabel PublisherLbl = new JLabel("Publisher:");
		PublisherLbl.setBounds(30, 144, 74, 16);
		contentPane.add(PublisherLbl);
		
		JLabel QuantityLbl = new JLabel("Quantity:");
		QuantityLbl.setBounds(30, 177, 56, 16);
		contentPane.add(QuantityLbl);
		
		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(237, 75, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setText("");
		textField_2.setBounds(237, 106, 116, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setText("");
		textField_3.setBounds(237, 141, 116, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setText("");
		textField_4.setBounds(237, 174, 116, 22);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton AddBookButton = new JButton("Add Book");
		AddBookButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=textField_1.getText();
				String author=textField_2.getText();
				String publisher=textField_3.getText();
				String quantity=textField_4.getText();
				int i=BookDao.save( name, author, publisher, quantity);
				if(i>0){
					JOptionPane.showMessageDialog(BooksForm.this,"Books added successfully!");
					LibrarianSuccess.main(new String[]{});
					frame.dispose();
					
				}else{
					JOptionPane.showMessageDialog(BooksForm.this,"Sorry, unable to save!");
				}
			}
		});
		AddBookButton.setBounds(86, 237, 97, 25);
		contentPane.add(AddBookButton);
		
		JButton BackButton = new JButton("Back");
		BackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LibrarianSuccess.main(new String[]{});
				frame.dispose();
			}
		});
		BackButton.setBounds(237, 237, 97, 25);
		contentPane.add(BackButton);
	}

}
